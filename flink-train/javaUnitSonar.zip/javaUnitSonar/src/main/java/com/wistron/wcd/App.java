package com.wistron.wcd;

/**
 * Hello world!
 *
 * sonar.junit.reportPaths
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
